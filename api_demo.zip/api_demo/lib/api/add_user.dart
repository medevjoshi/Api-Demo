import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InsertUserPage extends StatefulWidget {
  InsertUserPage(this.map) {
    print(map);
  }

  Map? map;

  @override
  State<InsertUserPage> createState() => _InsertUserPageState();
}

class _InsertUserPageState extends State<InsertUserPage> {
  var formKey = GlobalKey<FormState>();

  var nameController = TextEditingController();
  var cityController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.map == null) {
      nameController.text = "";
      cityController.text = "";
    } else {
      nameController.text = widget.map!['name'];
      cityController.text = widget.map!['city'];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
          key: formKey,
          child: Column(children: [
            Expanded(child: Container()),
            TextFormField(
                decoration: InputDecoration(hintText: 'Enter Name'),
                validator: (value) {
                  if (value != null && value.isEmpty) {
                    return "Enter Valid Name";
                  }
                },
                controller: nameController),
            TextFormField(
                decoration: InputDecoration(hintText: 'Enter City'),
                validator: (value) {
                  if (value != null && value.isEmpty) {
                    return "Enter Valid City";
                  }
                },
                controller: cityController),
            TextButton(
                onPressed: () {
                  if (formKey.currentState!.validate()) {
                    if (widget.map == null) {
                      insertUser()
                          .then((value) => Navigator.of(context).pop(true));
                    } else {
                      updateUser(widget.map!['id'])
                          .then((value) => Navigator.of(context).pop(true));
                    }
                  }
                },
                child: Container(
                    color: Colors.green,
                    child: Text(
                      'Submit',
                      style: TextStyle(color: Colors.white),
                    ))),
            Expanded(child: Container()),
          ])),
    );
  }

  Future<void> updateUser(id) async {
    Map map = {};
    map["name"] = nameController.text;
    map["city"] = cityController.text;

    var response1 = await http.put(
        Uri.parse('https://6312ca5ea8d3f673ffbf7931.mockapi.io/employees/$id'),
        body: map);
  }

  Future<void> insertUser() async {
    Map map = {};
    map["name"] = nameController.text;
    map["city"] = cityController.text;

    var response1 = await http.post(
        Uri.parse('https://6312ca5ea8d3f673ffbf7931.mockapi.io/employees'),
        body: map);
    print(response1.body);
  }
}
