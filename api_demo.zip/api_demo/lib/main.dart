import 'package:api_demo/api/api_demo.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: 'api_demo',
    routes: {'api_demo': (context) => api_demo()},
  ));
}
